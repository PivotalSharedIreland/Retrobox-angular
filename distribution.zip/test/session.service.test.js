System.register(['angular2/testing', "angular2/src/http/backends/mock_backend", "angular2/http", "angular2/core", "../app/sessions/session.service"], function(exports_1) {
    var testing_1, mock_backend_1, http_1, core_1, session_service_1, http_2;
    return {
        setters:[
            function (testing_1_1) {
                testing_1 = testing_1_1;
            },
            function (mock_backend_1_1) {
                mock_backend_1 = mock_backend_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
                http_2 = http_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (session_service_1_1) {
                session_service_1 = session_service_1_1;
            }],
        execute: function() {
            testing_1.describe('SessionService', function () {
                testing_1.beforeEachProviders(function () {
                    return [
                        http_1.HTTP_PROVIDERS,
                        core_1.provide(http_1.XHRBackend, { useClass: mock_backend_1.MockBackend }),
                        session_service_1.SessionService
                    ];
                });
                testing_1.it('logs in', testing_1.injectAsync([http_1.XHRBackend, session_service_1.SessionService], function (mockBackend, sessionService) {
                    return new Promise(function (resolve) {
                        mockBackend.connections.subscribe(function (connection) {
                            var data = JSON.parse(connection.request.text());
                            expect(data.email).toEqual("tester@example.com");
                            expect(data.password).toEqual("test-password");
                            expect(connection.request.url.toString()).toEqual("/api/sessions");
                            expect(connection.request.method).toEqual(http_2.RequestMethod.Post);
                            connection.mockRespond(new http_1.ResponseOptions({ status: 200 }));
                        });
                        sessionService.create("tester@example.com", "test-password").subscribe(function (res) {
                            expect(res.status).toBe(200);
                            resolve();
                        });
                    });
                }));
            });
        }
    }
});
//# sourceMappingURL=session.service.test.js.map